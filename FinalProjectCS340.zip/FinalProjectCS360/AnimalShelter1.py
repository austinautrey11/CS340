from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps
import json

class CRUD(object):
    """ CRUD operations for Animal collection in MongoDB """
#correct
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:51882/?authSource=AAC' % (username, password))
        self.database = self.client['AAC']
      #correct  
    # Method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            createAnimal = self.database.animals.insert(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False
    #correct output
    # Method to implement the R in CRUD.
    def read(self, data):
        
        # If search paramater is not None then find all matching documents
        if data is not None:
            match = self.database.animals.find(data, {"_id": False})
            return match
        else:
            print("Nothing to find, because the search parameter is empty")
            return False
    #correct output
    #Method to implement the U in CRUD
    def update(self, data, change):
        if data is not None:
            # data and change are dictionaries
            # update the animal id listed in data with new id change
            updateAnimal = self.database.animals.update(data,{"$set":change})
            return updateAnimal
        else:
            print('Nothing to update, because data parameter is empty')
            return false
            
     #correct output 
    # method to implement the D in CRUD
    def delete(self, data):
        #Verify that the record to be deleted has been supplied
        if data is not None:
            # delete the documents matching data criteria and print no. of documents deleted in json format
            delete_result = self.database.animals.delete_many(data)
            result = "Documents deleted: "+ json.dumps(delete_result.deleted_count)
            #print("Documents deleted ", json.dumps(delete_result.deleted_count))
            return result

        else:
            raise Exception("No record provided.")


